import React from "react";

function Uslovi() {
  return <div>Uslovi</div>;
}

export default Uslovi;
