import React from "react";

function Pravila() {
  return <div>Pravila</div>;
}

export default Pravila;
